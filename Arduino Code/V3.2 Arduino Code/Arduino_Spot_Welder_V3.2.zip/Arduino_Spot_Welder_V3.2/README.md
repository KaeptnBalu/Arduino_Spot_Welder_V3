This is the Arduino Code for the Spot Welder V3. 
Do not use it with the older V2 pcbs. It is not compatible with these.

You need to have the Ardafruit_GFX library and the Ardafruit_SSD1306 library installed in your Arduino IDE to sucessfully compile the Code.

You need to have the OptiBoot bootloader installed in your Arduino Nano to enable the reboot features of this code. If the standard bootloader is installed then on reboot the Nano will enter an infinite reboot loop.

To load and use the OptiBoot bootloader, add the following to your boards.txt file, burn the bootloader, then select ATmega328P OptiBoot to build the program;

## Arduino Nano OptiBoot w/ ATmega328
## ----------------------------------
nano.menu.cpu.OptiBootatmega328=ATmega328P OptiBoot

nano.menu.cpu.OptiBootatmega328.upload.maximum_size=30720
nano.menu.cpu.OptiBootatmega328.upload.maximum_data_size=2048
nano.menu.cpu.OptiBootatmega328.upload.speed=115200

nano.menu.cpu.OptiBootatmega328.bootloader.low_fuses=0xFF
nano.menu.cpu.OptiBootatmega328.bootloader.high_fuses=0xDA
nano.menu.cpu.OptiBootatmega328.bootloader.extended_fuses=0x05
nano.menu.cpu.OptiBootatmega328.bootloader.file=optiboot/optiboot_atmega328.hex

nano.menu.cpu.OptiBootatmega328.build.mcu=atmega328p

A typical location for boards.txt is C:\Users\<username>\AppData\Local\Arduino15\packages\arduino\hardware\avr\1.6.20




