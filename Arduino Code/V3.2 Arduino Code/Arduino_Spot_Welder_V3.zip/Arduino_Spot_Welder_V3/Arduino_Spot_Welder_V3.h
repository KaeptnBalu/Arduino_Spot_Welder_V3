#ifndef _ARDUINO_SPOT_WELDER_V3_H
#define _ARDUINO_SPOT_WELDER_V3_H
/***********************************************************************************************//**
 *  \par        Arduino Spot Welder - Header.
 *
 *  \par        Details
 *  \par
 *              Arduino Spot Welder V3 firmware.
 *              This is the Arduino Code for the Spot Welder V3. Do not use it with the older V2 
 *              pcbs. It is not compatible with these.
 *  \par
 *              You need to have the Ardafruit_GFX library and the Ardafruit_SSD1306 library 
 *              installed in your Arduino IDE to sucessfully compile the Code.
 *              You also need to have the OptiBoot bootloader installed in your Arduino Nano 
 *              to enable the reboot features of this code.
 *
 *  \file       Arduino_Spot_Welder_V3.h
 *  \author     Marc Schönfleisch <http://malectrics.eu/>
 *  \version    3.1
 *  \date       July 2017
 *  \copyright  Copyright(c)2017 Marc Schönfleisch <malectrics.info@gmail.com>. All right reserved.
 *
 *  \par        Changelog
 *  \li         01jul2017  MS  Initial release
 *  \li         12dec2017  JFF New release with major rewrite
 *  \li         15djan2018  MS change battery voltage reading for V3.2 Spot Welder 
 *
 *  \par        License
 *              This program is free software: you can redistribute it and/or modify it under the
 *              terms of the GNU General Public License as published by the Free Software 
 *              Foundation, either version 3 of the License, or (at your option) any later version.
 *  \par
 *              This program is distributed in the hope that it will be useful, but WITHOUT ANY 
 *              WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
 *              PARTICULAR PURPOSE.  See the GNU General Public License for more details.
 *  \par
 *              You should have received a copy of the GNU General Public License along with this 
 *              program.  If not, see <http://www.gnu.org/licenses/> or write to the Free Software 
 *              Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA.
 *
 *//***********************************************************************************************/

// Most of these macros define strings that appear on the splash screen 
// (each line of the splash screen is limited to 21 characters)
#define _DEVICENAME_        Arduino Spot Welder        
#define _PROGNAME_          Arduino Spot Welder Control Firmware      
#define _AUTHOR_            Marc Schonfleisch  
#define _VERSION_MAJOR_     3
#define _VERSION_MINOR_     2
#define _REVISION_          0
#define _DATE_              15jan2018
#define _COPYRIGHT_         2018      
#define _COMPANY_           Malectrics
#define _RIGHTS_            All right reserved

/***************************************************************************************************
* User Configuration                                                                               *
***************************************************************************************************/

//#define _DEVELOPMENT_                       /**< Allows printing of diagnostics */
//#define _BOOTSYS_                           /**< Force boot to system menu for testing */

#define _LANG_EN_                           /**< Language:  _LANG_EN/DE/FR/ES/IT_ */
//#define _TESTING_                           /**< Allows ignoring the low battery alarm */
#define _SERIAL_BAUD_       115200          /**< Comms rate for serial debugging */

/***************************************************************************************************
* Pin and interrupt definitions                                                                    *
***************************************************************************************************/

#define ENC_INT             0               /**< Rotary interrupt for CLK input (Ph0) */
#define PIN_CLK             2               /**< Rotary encoder CLK input (Ph0) */
#define PIN_DT              8               /**< Rotary encoder DT input (Ph1) */
#define PIN_SW              6               /**< Rotary encoder push button switch input */
#define PIN_FOOT_SWITCH     7               /**< Foot switch sense input */
#define PIN_AUTO_PULSE      3               /**< Auto-pulse sense input */
#define PIN_PULSE           5               /**< Weld pulse output */
#define PIN_LED             4               /**< Status LED output */
#define PIN_BATT_V          A0              /**< A/D input for battery voltage sense */

/***************************************************************************************************
* Macros                                                                                           *
***************************************************************************************************/

// Machine states
#define ST_STANDBY          0               /**< Machine state: standby */ 
#define ST_MAIN_SCREEN      1               /**< Machine state: display main screen */ 
#define ST_MAIN_SCREEN_CNT  2               /**< Machine state: display statistics */ 
#define ST_MENU_SCREEN      3               /**< Machine state: display menu screen */ 
#define ST_SUB_MENU_1       4               /**< Machine state: display sub-menu1 */ 
#define ST_SUB_MENU_2       5               /**< Machine state: display sub-menu2 */ 
#define ST_BATTERY_LOW      6               /**< Machine state: low battery voltage */ 

#define ST_SYSTEM_SCREEN    7               /**< Machine state: display system screen */ 
#define ST_SYSTEM_MENU      8               /**< Machine state: display system menu */ 
#define ST_SETTINGS_MENU    9               /**< Machine state: display settings menu */ 
#define ST_REBOOT_MENU      10              /**< Machine state: display reboot menu */ 
#define ST_MAXWELD_SCREEN   11              /**< Machine state: display max weld setting screen */ 
#define ST_BATTCAL_SCREEN   12              /**< Machine state: display battery calibration */
#define ST_INVERT_SCREEN    13              /**< Machine state: display invert setting screen */ 

// Private machine events
#define EV_NONE             0               /**< Machine event: no pending event */ 
#define EV_BTNDN            1               /**< Machine event: button pressed */ 
#define EV_BTNUP            2               /**< Machine event: button released */ 
#define EV_ENCUP            3               /**< Machine event: encoder rotate right */ 
#define EV_ENCDN            4               /**< Machine event: encoder rotate left */ 

// Public machine events
#define EV_BOOTDN           5               /**< Machine event: button pressed on boot */ 
#define EV_STBY_TIMEOUT     6               /**< Machine event: standby timer has timed out */
#define EV_BATT_LV          7               /**< Machine event: battery low voltage event */
#define EV_EEUPD            8               /**< Machine event: EEPROM needs updating */ 

 // Defaults for operational variables
#define DEF_AUTO_PLSDELAY   20              /**< Default auto pulse delay time (mS*100) */ 
#define DEF_PULSE_TIME      5              /**< Default pulse time (mS) */ 
#define DEF_MAX_PULSE_TIME  100             /**< Default maximum pulse time (mS) */ 
#define DEF_SPULSE_TIME     12              /**< Default short pulse time (% of pulse time) */ 
#define DEF_NOM_BATT_V      124             /**< Default nominal battery voltage (for testing) */
#define DEF_MAX_BATT_V      127             /**< Default maximum battery voltage (V*10) */
#define DEF_BATTERY_OFFSET  0               /**< Default battery calibration offset (V*10) */
#define DEF_BATT_ALARM      110             /**< Default low battery voltage (V*10) */
#define DEF_AUTO_PULSE      true           /**< Default Auto-pulse enable */ 
#define DEF_OLED_INVERT     false           /**< Default OLED orientation */ 

// Limits for operational variables
#define MIN_PULSE_TIME      3               /**< Minimum weld pulse time */
#define MAX_PULSE_TIME      500             /**< Absolute maximum weld pulse time */
#define MAX_APULSE_DELAY    50              /**< Maximum auto pulse delay */
#define MIN_APULSE_DELAY    5               /**< Minimum auto pulse delay */
#define MAX_SPULSE_TIME     100             /**< Maximum short pulse time */
#define MIN_SPULSE_TIME     1               /**< Minimum short pulse time */
#define MAX_BATT_ALARM      120             /**< Maximum low battery alarm voltage */
#define MIN_BATT_BALARM     100             /**< Minimum low battery alarm voltage */
#define MAX_BATT_V          200             /**< Absolute maximum battery voltage */
#define MIN_BATT_V          50              /**< Absolute minimum battery voltage */

// Timing macros
#define STANDBY_TIME_OUT    300000L         /**< Device sleep timeout (mS) */ 
#define EEPROM_UPDATE_T     5000            /**< EEPROM update time (mS) */
#define WP_RETRIGGER_DELAY  500             /**< Weld pulse re-trigger delay (mS) */
#define FS_TRIGGER_DELAY    200             /**< Foot switch activation delay (mS) */
#define RS_DEBOUNCE         50  /*20*/      /**< Rotary encoder & switch debounce time (mS) */
#define BV_INTERVAL         1000            /**< Battery voltage measurement interval (mS) */

// Display screen layout
#define CHR_W               6               /**< Width of character [size=1] (pixels) */   
#define CHR_H               8               /**< Height of character [size=1] (pixels) */   
#define LINE_H              (CHR_H+2)       /**< Height of line [size=1] (pixels) */   

// Macros to define logical states
#define DD_READ             true            /**< Data transfer direction - read */
#define DD_WRITE            false           /**< Data transfer direction - write */
#define P_ON                true            /**< General macro for ON state */
#define P_OFF               false           /**< General macro for OFF state */
#define B_DN                true            /**< General macro for DOWN state */
#define B_UP                false           /**< General macro for UP state */
#define PL_ACTIVE_H         false           /**< Pin logic macro for Active High */
#define PL_ACTIVE_L         true            /**< Pin logic macro for Active Low */

// EEPROM macros
#define EEA_ID              0               /**< Address of unique ID */
#define EEA_PDATA           (EEA_ID+4)      /**< Eeprom address of program data */
#define EE_UNIQUEID         0x18fae9c8      /**< Unique Eeprom verification ID */
#define EE_FULL_RESET       true            /**< Reset parameter to reset all Eeprom parameters */

// General macros
#define str(s)              #s
#define xstr(s)             str(s)

// Macros masquerading as functions - makes the code more readable
/** This macro reads the state of the pushbutton switch on the encoder. */
#define btnState()          (!digitalRead(PIN_SW))

/** This macro drives the welding pulse. */
#define weldPulse(state)    digitalWrite(PIN_PULSE,state?HIGH:LOW)

/** Where has this macro gone?? It was in WString.h */
#define FPSTR(pstr_pointer) (reinterpret_cast<const __FlashStringHelper *>(pstr_pointer))               

/***************************************************************************************************
* OLED Display Configuration                                                                       *
***************************************************************************************************/

#define OLED_RESET          4               /**< OLED mode */
#define OLED_INVERT         2               /**< OLED defined orientation mode - check OLED doc'n */
#define SPLASHTIME          5000            /**< Splash screen time (mS) */

// SD1306_LCDHEIGHT must be defined in Adafruit_SSD1306.h
#if (SSD1306_LCDHEIGHT != 64)               
#error("Height incorrect, please fix Adafruit_SSD1306.h");
#endif

/***************************************************************************************************
* Structure, union, and enumerated type definitions                                                *
***************************************************************************************************/

typedef  enum {                             /**< Type enumerations for format of variables */
         VF_BATTALM,                        /**< Battery alarm voltage */
         VF_BATTV,                          /**< Battery voltage */
         VF_WELDCNT,                        /**< Weld count */
         VF_PLSDLY,                         /**< Pulse delay */
         VF_SHTPLS,                         /**< Short pulse duration */
         VF_DELAY                           /**< Delay */
} vf_Type;

typedef  struct   progData {                /**< Program operating data structure */
         uint8_t  autoPulseDelay;           /**< Auto-pulse delay (mS/100) */ 
         uint8_t  batteryAlarm;             /**< Low battery voltage (A/D count) */
         uint16_t weldCount;                /**< Count of welds performed */
         uint16_t pulseTime;                /**< Pulse time (mS) */ 
         uint16_t maxPulseTime;             /**< Maximum allowed pulse time (mS) */ 
         uint8_t  shortPulseTime;           /**< Short pulse time (% of pulse time) */ 
         int8_t   batteryOffset;            /**< Battery voltage calibration offset (signed) x10 */
         struct progFlags {                 /**< Program logical flags */
             unsigned en_autoPulse:  1;     /**< Auto-pulse enable */ 
             unsigned en_oledInvert: 1;     /**< OLED orientation - true for inverted else normal */
             unsigned unused:        6;     /**< Unused program flags */ 
         } pFlags;
} progData;

/***************************************************************************************************
* Global program variables and objects                                                             *
***************************************************************************************************/

// Structures and objects
progData  pData;                            /**< Program operating data */
Adafruit_SSD1306 display(OLED_RESET);       /**< OLED display object */

// Static variables
uint8_t  mState         = ST_MAIN_SCREEN;   /**< Current machine state */
uint8_t  batteryVoltage = DEF_NOM_BATT_V;   /**< Current battery voltage x10 */
int8_t   batt_gauge;                        /**< Battery gauge segments to display */
boolean  sysMenu        = false;            /**< In the system menu structure */

// Volatile variables - will be changed by the ISR  
volatile unsigned long lastActiveTime;
volatile uint8_t mEvent = EV_NONE;          /**< Current pending machine event */

/***************************************************************************************************
* Procedure prototypes                                                                             *
***************************************************************************************************/

void     stateMachine();
void     eepromReset(boolean = false);
void     updateEeprom();
void     checkForLowVoltageEvent();
void     checkForSleepEvent();
void     checkForBtnEvent();
void     isr();
void     splash();
void     sendWeldPulse(uint8_t, uint16_t, uint16_t, boolean = PL_ACTIVE_H);  
void     message(const __FlashStringHelper*, const __FlashStringHelper*,
                 const __FlashStringHelper*, uint8_t = 0);
void     displayMenuType1(const __FlashStringHelper*, const __FlashStringHelper*,
                          const __FlashStringHelper*, const __FlashStringHelper*, 
                          uint8_t SelectedItem);
void     displayMenuType2(const __FlashStringHelper*, const char*, const __FlashStringHelper*);
void     displayMainScreen();
void     displayLowBattery();
void     drawStatusLine();
void     setTextProp(uint8_t, uint8_t, uint8_t, uint16_t = WHITE, boolean = false);
char*    valStr(char*, uint16_t, vf_Type);

/***************************************************************************************************
* Language strings (very simple language implementation - English is the default)                  *
***************************************************************************************************/

// Copy the language strings from the else clause into your language specific clause, then alter
// the strings to suit your language. Define your language at the top of this header file. It is
// important to maintain the correct formatting of the strings. Each string has an inline comment
// defining its format.

// Comment legend: field width          21 for small font, 10 for large font
//                 justification        left, centre, right
//                 padded               spaces both ends to fill field

#ifdef _LANG_DE_
          
#elif defined _LANG_FR_

#elif defined _LANG_ES_

#elif defined _LANG_IT_

#else
//                                           0123456789               // large font
//                                           012345678901234567890    // small font

static const char LS_APULSE[]     PROGMEM = "Auto Pulse";             // 10 char, centre, padded
static const char LS_BATTALM1[]   PROGMEM = "Batt Alarm";             // 10 char, centre, padded
static const char LS_SHORTPLS1[]  PROGMEM = "Shrt Pulse";             // 10 char, centre, padded

static const char LS_MANAUTO[]    PROGMEM = " Activate ";             // 10 char, centre, padded
static const char LS_DELAY[]      PROGMEM = "  Delay   ";             // 10 char, centre, padded
static const char LS_EXIT[]       PROGMEM = "  Exit    ";             // 10 char, centre, padded

static const char LS_STANDBY[]    PROGMEM = "  STANDBY ";             // 10 char, centre, padded
static const char LS_CLICKBTN[]   PROGMEM = " Please Click Button";   // 21 char, left
static const char LS_EXITSTBY[]   PROGMEM = "   to Exit Standby";     // 21 char, left

static const char LS_BATTALM[]    PROGMEM = "Battery Alarm";          // 21 char, left
static const char LS_BATTERY[]    PROGMEM = "BATTERY";                // 10 char, left
static const char LS_LOWV[]       PROGMEM = "LOW VOLTS";              // 10 char, left

static const char LS_AUTOPLSON[]  PROGMEM = "Auto Pulse Activate";    // 21 char, left
static const char LS_AUTO[]       PROGMEM = "AUTO";                   // 10 char, left
static const char LS_MANUAL[]     PROGMEM = "MANUAL";                 // 10 char, left

static const char LS_AUTOPLSDLY[] PROGMEM = "Auto Pulse Delay";       // 21 char, left
static const char LS_SHORTPLS[]   PROGMEM = "Short Pulse";            // 21 char, left
static const char LS_WPDRN[]      PROGMEM = "Weld Pulse Duration";    // 21 char, left

static const char LS_BATTMSG[]    PROGMEM = " Battery";               // 10 char, centre
static const char LS_MAXPMSG[]    PROGMEM = "   Duration Set";        // 21 char, centre

static const char LS_PCOF[]       PROGMEM = "% of Pulse Time";        // 21 char, left
static const char LS_SECONDS[]    PROGMEM = "Seconds";                // 21 char, left
static const char LS_VOLTAGE[]    PROGMEM = "Volts";                  // 21 char, left
static const char LS_MS[]         PROGMEM = "mS";                     // 2  char, left
static const char LS_VUNITS[]     PROGMEM = "V";                      // 1  char, left
static const char LS_WELDS[]      PROGMEM = "W";                      // 1  char, left

static const char LS_REBOOTFR[]   PROGMEM = "   with Full Reset";     // 21 char, centre
static const char LS_REBOOTNR[]   PROGMEM = "   without Reset";       // 21 char, centre
static const char LS_REBOOTSR[]   PROGMEM = "   with Safe Reset";     // 21 char, centre
static const char LS_RECALMSG[]   PROGMEM = "   re-calibrated";       // 21 char, centre
static const char LS_WAITMSG[]    PROGMEM = "    PLEASE WAIT";        // 21 char, centre

static const char LS_SYSMENU[]    PROGMEM = "System Menu";            // 21 char, left
static const char LS_SETTINGS[]   PROGMEM = " Settings ";             // 10 char, centre, padded
static const char LS_DISPLAY[]    PROGMEM = "  Display ";             // 10 char, centre, padded
static const char LS_BOOT[]       PROGMEM = "   Boot   ";             // 10 char, centre, padded

static const char LS_SETTMENU[]   PROGMEM = "System Settings";        // 21 char, left
static const char LS_MAXPULSE[]   PROGMEM = "Max Pulse ";             // 10 char, centre, padded
static const char LS_BATTCAL[]    PROGMEM = " Batt Cal ";             // 10 char, centre, padded

static const char LS_BOOTMENU[]   PROGMEM = "Reboot Spot Welder";     // 21 char, left
static const char LS_REBOOT[]     PROGMEM = "  Reboot  ";             // 10 char, centre, padded  
static const char LS_SAFERST[]    PROGMEM = "Safe Reset";             // 10 char, centre, padded
static const char LS_FULLRST[]    PROGMEM = "Full Reset";             // 10 char, centre, padded

static const char LS_INVERTMENU[] PROGMEM = "Screen Orientation";     // 21 char, left
static const char LS_SCRNORM[]    PROGMEM = "NORMAL";                 // 10 char, left
static const char LS_SCRINV[]     PROGMEM = "INVERTED";               // 10 char, left

static const char LS_MAXPLSMENU[] PROGMEM = "Set Max Weld Pulse";     // 21 char, left

static const char LS_BATCALMENU[] PROGMEM = "Calibrate Battery";      // 21 char, left
static const char LS_BATCALMSG[]  PROGMEM = "Set Measured Volts";     // 21 char, left
static const char LS_MSGHDR[]     PROGMEM = "System Message";         // 21 char, left

#endif            

#endif // _ARDUINO_SPOT_WELDER_V3_H

// EOF Arduino_Spot_Welder_V3.h
 

